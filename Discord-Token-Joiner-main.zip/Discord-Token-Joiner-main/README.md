# Discord Token Joiner 🪐
The best token joiner for Discord, with captcha solver, rules bypass, and nickname changer (optional)!

## 📹 Preview

https://github.com/H4cK3dR4Du/Crunchyroll-Account-Checker/assets/118562174/344619ae-883c-40bd-a805-297db331cd31

## 🔥 Features
- Fully Requests Based Joiner
- Fastest Discord Token Joiner
- HTTP & HTTPS Proxy Support
- Multi Proxy Support
- Captcha Solver
- Nickname Changer
- Bypass Rules
- Doesn't Flag Any Token
- Slick UI
- Simple & Easy To Setup

## ✍️ Usage
1. Edit `proxies.txt` file and set your proxies
   
2. Edit `config.json` with your custom settings

3. Open `main.py` and enjoy! :)

## ⚠️ DISCLAIMER / NOTES
This github repo is for EDUCATIONAL PURPOSES ONLY. I am NOT under any responsibility if a problem occurs.
I have made this GitHub repository in just 2 hours. If there is any issue, please contact me through my Discord.

## ✨ Issues / Doubts

- If you have any questions do not hesitate to enter my discord: https://discord.gg/hcuxjpSfkU
- Or if you have any error do not forget to report it in: [issues](https://github.com/H4cK3dR4Du/Discord-Token-Joiner/issues/new)
